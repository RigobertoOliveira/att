from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem, QPushButton
from database import obter_classificacao

class TabelaClassificacao(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Tabela de Classificação")
        self.setFixedSize(400, 300)  # Tamanho fixo
        self.setStyleSheet("background-color: #2b2b2b; color: white;")

        layout = QVBoxLayout(self)

        self.instrucao = QLabel("Classificação Geral:")
        self.instrucao.setStyleSheet("color: white; font-size: 18px;")
        layout.addWidget(self.instrucao)

        # Criação da tabela para a classificação
        self.tabela = QTableWidget(0, 2)  # 0 linhas inicialmente, 2 colunas: Nome e Pontuação
        self.tabela.setHorizontalHeaderLabels(["Nome", "Pontuação"])
        self.tabela.setStyleSheet("QTableWidget {background-color: #333; color: white;}")
        self.tabela.horizontalHeader().setStyleSheet("QHeaderView::section { background-color: #444; }")
        self.tabela.setColumnWidth(0, 250)  # Ajusta a largura da coluna de nomes
        layout.addWidget(self.tabela)

        # Botão para fechar a janela de classificação
        self.fechar_button = QPushButton("Fechar")
        self.fechar_button.setStyleSheet(self.style_botao())
        self.fechar_button.clicked.connect(self.close)
        layout.addWidget(self.fechar_button)

        self.carregar_classificacao()

    def style_botao(self):
        return """
            QPushButton {
                background-color: #d32f2f;
                color: white;
                border-radius: 10px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #b71c1c;
            }
        """

    def carregar_classificacao(self):
        classificacao = obter_classificacao()  # Obtém a classificação do banco de dados

        # Adiciona os dados na tabela
        for nome, pontuacao in classificacao:
            row_position = self.tabela.rowCount()
            self.tabela.insertRow(row_position)
            self.tabela.setItem(row_position, 0, QTableWidgetItem(nome))
            self.tabela.setItem(row_position, 1, QTableWidgetItem(str(pontuacao)))
