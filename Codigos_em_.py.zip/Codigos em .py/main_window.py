# main_window.py
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from tabuada import TabuadaGame
from fibonacci import FibonacciGame  # Certifique-se de importar a classe FibonacciGame
from raiz_quadrada import RaizQuadradaGame  # Importar a nova classe RaizQuadradaGame
from database import create_tables, verificar_jogador


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Jogo de Matemática")
        self.setFixedSize(400, 300)  # Tamanho fixo
        self.setStyleSheet("background-color: #2b2b2b; color: white;")

        layout = QVBoxLayout()

        # Entrada de Nome
        self.nome_label = QLabel("Nome:")
        self.nome_label.setStyleSheet("color: white;")
        layout.addWidget(self.nome_label)

        self.nome_input = QLineEdit(self)
        layout.addWidget(self.nome_input)

        # Entrada de Número de Chamada
        self.numero_label = QLabel("Número de Chamada:")
        self.numero_label.setStyleSheet("color: white;")
        layout.addWidget(self.numero_label)

        self.numero_input = QLineEdit(self)
        layout.addWidget(self.numero_input)

        # Botão de Iniciar
        self.enviar_button = QPushButton("Iniciar")
        self.enviar_button.setStyleSheet(self.style_botao())
        self.enviar_button.clicked.connect(self.iniciar_jogo)
        layout.addWidget(self.enviar_button)

        self.setLayout(layout)
        create_tables()  # Certifica que as tabelas do banco de dados foram criadas

    def style_botao(self):
        return """
            QPushButton {
                background-color: #d32f2f;
                color: white;
                border-radius: 10px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #b71c1c;
            }
        """

    def iniciar_jogo(self):
        nome = self.nome_input.text()
        numero = self.numero_input.text()

        print(f"Nome inserido: {nome}, Número inserido: {numero}")  # Verifique a entrada

        if nome and numero.isdigit():
            jogador_existe = verificar_jogador(nome, int(numero))  # Verifica se o jogador existe
            print(f"Jogador existe: {jogador_existe}")

            if jogador_existe:
                self.janela_jogo = SelecionarJogo(jogador_id=int(numero))  # Nova janela para seleção de jogo
                self.janela_jogo.show()
                self.close()
            else:
                QMessageBox.warning(self, "Erro", "Nome ou número de chamada incorretos.")
        else:
            QMessageBox.warning(self, "Erro", "Por favor, insira um nome e número de chamada válido.")


class SelecionarJogo(QWidget):
    def __init__(self, jogador_id):
        super().__init__()
        self.jogador_id = jogador_id
        self.setWindowTitle("Selecionar Jogo")
        self.setFixedSize(400, 300)  # Tamanho fixo
        self.setStyleSheet("background-color: #2b2b2b; color: white;")

        layout = QVBoxLayout()

        self.instrucao = QLabel("Selecione um jogo:")
        self.instrucao.setStyleSheet("color: white;")
        layout.addWidget(self.instrucao)

        # Botão para o jogo de Tabuada
        self.tabuada_button = QPushButton("Tabuada")
        self.tabuada_button.setStyleSheet(self.style_botao())
        self.tabuada_button.clicked.connect(self.jogar_tabuada)
        layout.addWidget(self.tabuada_button)

        # Botão para o jogo de Fibonacci
        self.fibonacci_button = QPushButton("Fibonacci")
        self.fibonacci_button.setStyleSheet(self.style_botao())
        self.fibonacci_button.clicked.connect(self.jogar_fibonacci)  # Conecte o botão ao jogo de Fibonacci
        layout.addWidget(self.fibonacci_button)

        # Botão para o jogo de Raiz Quadrada
        self.raiz_button = QPushButton("Raiz Quadrada")
        self.raiz_button.setStyleSheet(self.style_botao())
        self.raiz_button.clicked.connect(self.jogar_raiz_quadrada)  # Conecte o botão ao jogo de Raiz Quadrada
        layout.addWidget(self.raiz_button)

        self.setLayout(layout)

    def style_botao(self):
        return """
            QPushButton {
                background-color: #d32f2f;
                color: white;
                border-radius: 10px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #b71c1c;
            }
        """

    def jogar_tabuada(self):
        self.janela_tabuada = TabuadaGame(self.jogador_id)
        self.janela_tabuada.show()
        self.close()

    def jogar_fibonacci(self):
        self.janela_fibonacci = FibonacciGame(self.jogador_id)  # Inicie o jogo de Fibonacci
        self.janela_fibonacci.show()
        self.close()

    def jogar_raiz_quadrada(self):
        self.janela_raiz = RaizQuadradaGame(self.jogador_id)  # Inicie o jogo de Raiz Quadrada
        self.janela_raiz.show()
        self.close()
