# main.py
import sys
from PyQt5.QtWidgets import QApplication
from main_window import MainWindow

if __name__ == "__main__":
    app = QApplication(sys.argv)

    # Cria a janela principal
    main_window = MainWindow()
    main_window.show()

    # Mantém a aplicação aberta até que o usuário feche a janela
    sys.exit(app.exec_())
