from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QLineEdit, QMessageBox, QTableWidget, QTableWidgetItem
from PyQt5.QtCore import QTimer
import random
from database import registrar_pontuacao, obter_classificacao

class ClassificacaoGeral(QWidget):
    def __init__(self, classificacao):
        super().__init__()
        self.setWindowTitle("Classificação Geral")
        self.setFixedSize(400, 300)  # Tamanho fixo
        self.setStyleSheet("background-color: #2b2b2b; color: white;")

        layout = QVBoxLayout(self)

        self.instrucao = QLabel("Classificação Geral:")
        self.instrucao.setStyleSheet("color: white; font-size: 18px;")
        layout.addWidget(self.instrucao)

        # Criação da tabela para a classificação
        self.tabela = QTableWidget(len(classificacao), 2)  # 2 colunas: Nome e Pontuação
        self.tabela.setHorizontalHeaderLabels(["Nome", "Pontuação"])
        self.tabela.setStyleSheet("QTableWidget {background-color: #333; color: white;}")
        layout.addWidget(self.tabela)

        # Preencher a tabela com a classificação
        for i, (nome, pontuacao) in enumerate(classificacao):
            self.tabela.setItem(i, 0, QTableWidgetItem(nome))
            self.tabela.setItem(i, 1, QTableWidgetItem(str(pontuacao)))

        # Botão para fechar a janela de classificação
        self.fechar_button = QPushButton("Fechar")
        self.fechar_button.setStyleSheet(self.style_botao())
        self.fechar_button.clicked.connect(self.close)
        layout.addWidget(self.fechar_button)

    def style_botao(self):
        return """
            QPushButton {
                background-color: #d32f2f;
                color: white;
                border-radius: 10px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #b71c1c;
            }
        """


class TabuadaGame(QWidget):
    def __init__(self, jogador_id):
        super().__init__()
        self.jogador_id = jogador_id
        self.setWindowTitle("Jogo de Tabuada")
        self.setFixedSize(600, 500)  # Tamanho fixo
        self.setStyleSheet("background-color: #2b2b2b; color: white;")

        self.layout = QVBoxLayout(self)

        self.instrucao = QLabel("Selecione o modo de jogo:")
        self.instrucao.setStyleSheet("color: white;")
        self.layout.addWidget(self.instrucao)

        # Botões para os modos de jogo
        self.treinamento_button = QPushButton("Treinamento")
        self.treinamento_button.setStyleSheet(self.style_botao())
        self.treinamento_button.clicked.connect(self.selecionar_dificuldade_treinamento)
        self.layout.addWidget(self.treinamento_button)

        self.competitivo_button = QPushButton("Competitivo")
        self.competitivo_button.setStyleSheet(self.style_botao())
        self.competitivo_button.clicked.connect(self.modo_competitivo)
        self.layout.addWidget(self.competitivo_button)

        # Botão para ver a classificação geral
        self.classificacao_button = QPushButton("Ver Classificação Geral")
        self.classificacao_button.setStyleSheet(self.style_botao())
        self.classificacao_button.clicked.connect(self.mostrar_classificacao)  # Conecte ao método que mostra a classificação
        self.layout.addWidget(self.classificacao_button)

        self.resultado_label = QLabel(" ")
        self.resultado_label.setStyleSheet("color: white; font-size: 16px;")
        self.layout.addWidget(self.resultado_label)

    def style_botao(self):
        return """
            QPushButton {
                background-color: #d32f2f;
                color: white;
                border-radius: 10px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #b71c1c;
            }
        """

    def selecionar_dificuldade_treinamento(self):
        self.clear_layout(preserve_widgets=[self.instrucao, self.resultado_label])
        self.instrucao.setText("Selecione a dificuldade do treinamento:")

        # Botões para cada dificuldade
        dificuldades = ["Fácil", "Normal", "Médio", "Difícil"]
        for dificuldade in dificuldades:
            button = QPushButton(dificuldade)
            button.setStyleSheet(self.style_botao())
            button.clicked.connect(lambda _, d=dificuldade: self.modo_treinamento(d))
            self.layout.addWidget(button)

    def clear_layout(self, preserve_widgets=[]):
        """Remove todos os widgets do layout, exceto aqueles fornecidos na lista preserve_widgets."""
        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget and widget not in preserve_widgets:
                widget.deleteLater()

    def modo_treinamento(self, dificuldade):
        self.clear_layout(preserve_widgets=[self.instrucao, self.resultado_label])
        self.instrucao.setText(f"Modo Treinamento ({dificuldade}): Resolva as operações e veja dicas")

        self.questao_label = QLabel("")
        self.layout.addWidget(self.questao_label)

        self.resposta_input = QLineEdit(self)
        self.resposta_input.returnPressed.connect(lambda: self.verificar_resposta(dificuldade))
        self.layout.addWidget(self.resposta_input)

        # Mostrar as dicas específicas
        self.dicas_label = QLabel(self.dicas_por_dificuldade(dificuldade))
        self.dicas_label.setStyleSheet("color: white; font-size: 12px;")
        self.layout.addWidget(self.dicas_label)

        self.resultado_label = QLabel("")  # Reseta o resultado
        self.layout.addWidget(self.resultado_label)

        self.botao_voltar = QPushButton("Voltar")
        self.botao_voltar.setStyleSheet(self.style_botao())
        self.botao_voltar.clicked.connect(self.voltar_menu)
        self.layout.addWidget(self.botao_voltar)

        self.iniciar_treinamento(dificuldade)

    def dicas_por_dificuldade(self, dificuldade):
        dicas = {
            "Fácil": """1. Lembre-se que multiplicar por 1 mantém o número.
2. Multiplicar por 10 adiciona um zero ao número.
3. Multiplicar por 2 é o mesmo que somar o número duas vezes.
4. Memorize as tabuadas menores para facilitar.
5. Use os dedos para multiplicar por 5 se precisar.""",
            "Normal": """1. Multiplicar por 3 é o mesmo que somar o número três vezes.
2. A tabuada do 4 pode ser feita dobrando o número duas vezes.
3. Multiplicar por 6 é mais fácil quando você já sabe a tabuada do 3.
4. Para multiplicar por 9, tente usar as mãos: dobre os dedos para ver os resultados.
5. Pratique as tabuadas de 7 e 8 frequentemente, pois são as mais difíceis.""",
            "Médio": """1. Multiplicar por 11 é fácil: só repita o número (exemplo: 4 x 11 = 44).
2. A tabuada do 12 é mais fácil se você somar o número a si mesmo 12 vezes.
3. Para multiplicar por números grandes, divida o número em partes menores.
4. Use a técnica de 'quebrar' números grandes: por exemplo, 9 x 6 é o mesmo que 10 x 6 - 6.
5. A tabuada do 15 é útil em muitas situações, então vale a pena memorizar.""",
            "Difícil": """1. Para números grandes, tente usar a decomposição de fatores.
2. Multiplicações com dois dígitos podem ser facilitadas usando estimativas.
3. Multiplicar números pares é mais rápido se você dividir antes de multiplicar.
4. Aprenda a usar os padrões das tabuadas: alguns números têm padrões repetidos.
5. Multiplicar por números próximos de 100 é mais fácil do que parece (exemplo: 98 x 6 pode ser resolvido mais rápido com aproximações)."""
        }
        return dicas[dificuldade]

    def iniciar_treinamento(self, dificuldade):
        if dificuldade == "Fácil":
            self.numero1 = random.randint(1, 5)
            self.numero2 = random.randint(1, 5)
        elif dificuldade == "Normal":
            self.numero1 = random.randint(1, 10)
            self.numero2 = random.randint(1, 10)
        elif dificuldade == "Médio":
            self.numero1 = random.randint(5, 15)
            self.numero2 = random.randint(5, 15)
        else:  # Difícil
            self.numero1 = random.randint(10, 20)
            self.numero2 = random.randint(10, 20)

        self.questao_label.setText(f"Quanto é {self.numero1} x {self.numero2}?")

    def verificar_resposta(self, dificuldade):
        try:
            resposta = int(self.resposta_input.text())
            if resposta == self.numero1 * self.numero2:
                self.resultado_label.setText("Acertou!")
                registrar_pontuacao(self.jogador_id, 10)  # Registrar pontuação
            else:
                self.resultado_label.setText(f"Errou! A resposta correta é {self.numero1 * self.numero2}.")
        except ValueError:
            self.resultado_label.setText("Por favor, insira um número válido.")
        self.resposta_input.clear()
        self.iniciar_treinamento(dificuldade)

    def voltar_menu(self):
        self.clear_layout(preserve_widgets=[self.instrucao, self.resultado_label])
        self.instrucao.setText("Selecione o modo de jogo:")
        self.layout.addWidget(self.treinamento_button)
        self.layout.addWidget(self.competitivo_button)
        self.layout.addWidget(self.classificacao_button)

    def modo_competitivo(self):
        self.clear_layout(preserve_widgets=[self.instrucao, self.resultado_label])  # Mantém o QLabel de instrução e resultado
        self.resultado_label.setText("")

        self.instrucao.setText("Modo Competitivo: Resolva o máximo que puder em 60 segundos!")

        self.pontuacao = 0
        self.tempo = 60

        # Exibir o tempo restante
        self.tempo_label = QLabel(f"Tempo restante: {self.tempo}")
        self.tempo_label.setStyleSheet("color: white; font-size: 16px;")
        self.layout.addWidget(self.tempo_label)

        # Exibir a pontuação atual
        self.pontuacao_label = QLabel(f"Pontuação: {self.pontuacao} - Última Resposta: ")
        self.pontuacao_label.setStyleSheet("color: white; font-size: 16px;")
        self.layout.addWidget(self.pontuacao_label)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.atualizar_tempo)
        self.timer.start(1000)

        self.botao_voltar = QPushButton("Voltar")
        self.botao_voltar.setStyleSheet(self.style_botao())
        self.botao_voltar.clicked.connect(self.voltar_menu)
        self.layout.addWidget(self.botao_voltar)

        self.botao_classificacao = QPushButton("Ver Classificação Geral")
        self.botao_classificacao.setStyleSheet(self.style_botao())
        self.botao_classificacao.clicked.connect(self.mostrar_classificacao)
        self.layout.addWidget(self.botao_classificacao)

        self.iniciar_competicao()

    def iniciar_competicao(self):
        self.numero1 = random.randint(1, 10)
        self.numero2 = random.randint(1, 10)

        if hasattr(self, 'questao_label'):
            self.questao_label.setText(f"Quanto é {self.numero1} x {self.numero2}?")
        else:
            self.questao_label = QLabel(f"Quanto é {self.numero1} x {self.numero2}?")
            self.layout.addWidget(self.questao_label)

        if hasattr(self, 'resposta_input'):
            self.resposta_input.clear()  # Limpa o campo de resposta
        else:
            self.resposta_input = QLineEdit(self)
            self.resposta_input.returnPressed.connect(self.verificar_resposta_competicao)
            self.layout.addWidget(self.resposta_input)

        if hasattr(self, 'resultado_label'):
            self.resultado_label.setText("")  # Reseta o resultado
        else:
            self.resultado_label = QLabel("")  # Reseta o resultado
            self.layout.addWidget(self.resultado_label)

    def verificar_resposta_competicao(self):
        resposta = self.resposta_input.text()
        if resposta.isdigit():
            resposta = int(resposta)
            correto = self.numero1 * self.numero2
            if resposta == correto:
                self.pontuacao += 10
                self.resultado_label.setText("Você acertou! (+10 pontos)")
                self.pontuacao_label.setText(f"Pontuação: {self.pontuacao} - Última Resposta: Correta")  # Atualiza a pontuação
            else:
                self.resultado_label.setText(f"Errado! A resposta correta era {correto}.")
                self.pontuacao_label.setText(f"Pontuação: {self.pontuacao} - Última Resposta: Errada")  # Atualiza a pontuação
        else:
            self.resultado_label.setText("Por favor, insira um número válido.")

        self.resposta_input.clear()  # Limpa o campo de resposta após cada tentativa
        self.iniciar_competicao()  # Inicia uma nova pergunta sem criar novos widgets

    def atualizar_tempo(self):
        self.tempo -= 1
        self.tempo_label.setText(f"Tempo restante: {self.tempo}")  # Atualiza o tempo na tela
        if self.tempo == 0:
            self.timer.stop()
            registrar_pontuacao(self.jogador_id, "Tabuada", "Competitivo", self.pontuacao)
            QMessageBox.information(self, "Fim do Jogo", f"Sua pontuação foi {self.pontuacao} pontos!")
            self.mostrar_classificacao()

    def mostrar_classificacao(self):
        classificacao = obter_classificacao()  # Obtenha a classificação do banco de dados
        self.classificacao_window = ClassificacaoGeral(classificacao)
        self.classificacao_window.show()

    def voltar_menu(self):
        self.clear_layout(preserve_widgets=[self.instrucao, self.resultado_label])  # Mantém o QLabel de instrução e resultado
        self.instrucao.setText("Selecione o modo de jogo:")

        # Recria os botões do menu principal
        self.treinamento_button = QPushButton("Treinamento")
        self.treinamento_button.setStyleSheet(self.style_botao())
        self.treinamento_button.clicked.connect(self.selecionar_dificuldade_treinamento)
        self.layout.addWidget(self.treinamento_button)

        self.competitivo_button = QPushButton("Competitivo")
        self.competitivo_button.setStyleSheet(self.style_botao())
        self.competitivo_button.clicked.connect(self.modo_competitivo)
        self.layout.addWidget(self.competitivo_button)

        self.resultado_label.setText("")  # Limpa o resultado anterior